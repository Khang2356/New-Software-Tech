$( "#a" ).removeClass( "choosen choosen" ).addClass( "choosen" );
