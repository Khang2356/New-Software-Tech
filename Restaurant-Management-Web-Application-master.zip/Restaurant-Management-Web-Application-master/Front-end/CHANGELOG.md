# Changelog

## [1.1.0] 2019-07-01

### Bootstrap Update, Libraries Update

- Bootstrap updated to `4.3.1`
- libraries updated to latest versions
- fixed issues


## [1.0.0] 2018-09-26

### Original Release
