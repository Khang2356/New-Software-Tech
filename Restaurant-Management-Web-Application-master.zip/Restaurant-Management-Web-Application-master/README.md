# Restaurant-Management-Web-Application
# Team PWD(PROFESSIONAL WEBSITE DEVELOPER)

#Project name: Restaurant-Management-Web-Application

#Description: Build restaurant management website application with Bootstrap4, AngularJS, and Spring Boot

#Operating system: Window10

#Technology: Bootstrap4, AngularJS, and Spring Boot

#Database: MySQL

#IDE: Atom, Visual Studio Code, and Spring Tool Suit4

#Member:
- NGUYỄN THANH VIỆT (LEADER)
- NGUYỄN VĂN HIỆP
- ĐỖ MINH TÂM
- BÙI NGỌC DANH
- NGUYỄN PHẠM ĐÌNH KHANG

#Link:

Link Github: https://github.com/VIETDEPTRAII/Restaurant-Management-Web-Application

Link Redmine: http://pms.saigontech.edu.vn:8080/login

Link Google Drive: https://drive.google.com/drive/folders/1Yt3IMEjHYuGb0ju6XyFtca0dDP8ND574
